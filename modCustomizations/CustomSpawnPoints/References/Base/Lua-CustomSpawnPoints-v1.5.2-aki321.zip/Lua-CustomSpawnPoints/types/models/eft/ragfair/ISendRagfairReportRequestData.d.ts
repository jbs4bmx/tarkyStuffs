export interface ISendRagfairReportRequestData {
    offerId: number;
}
