export declare enum LogBackgroundColor {
    DEFAULT = "",
    BLACK = "blackBG",
    RED = "redBG",
    GREEN = "greenBG",
    YELLOW = "yellowBG",
    BLUE = "blueBG",
    MAGENTA = "magentaBG",
    CYAN = "cyanBG",
    WHITE = "whiteBG"
}
