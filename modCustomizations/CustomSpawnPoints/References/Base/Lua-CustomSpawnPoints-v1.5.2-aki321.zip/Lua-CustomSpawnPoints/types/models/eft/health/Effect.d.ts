export declare enum Effect {
    FRACTURE = "Fracture",
    LIGHT_BLEEDING = "LightBleeding",
    HEAVY_BLEEDING = "HeavyBleeding"
}
