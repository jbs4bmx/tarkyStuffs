export interface IHideoutSettingsBase {
    generatorSpeedWithoutFuel: number;
    generatorFuelFlowRate: number;
    airFilterUnitFlowRate: number;
    gpuBoostRate: number;
}
