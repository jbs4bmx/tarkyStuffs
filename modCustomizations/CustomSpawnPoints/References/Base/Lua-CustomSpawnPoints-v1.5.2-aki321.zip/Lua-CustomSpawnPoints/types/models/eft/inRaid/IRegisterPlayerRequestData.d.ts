export interface IRegisterPlayerRequestData {
    crc: number;
    locationId: string;
    variantId: number;
}
