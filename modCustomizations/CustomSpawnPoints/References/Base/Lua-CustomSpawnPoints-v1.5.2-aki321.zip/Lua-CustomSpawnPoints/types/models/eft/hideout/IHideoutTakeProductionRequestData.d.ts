export interface IHideoutTakeProductionRequestData {
    Action: "HideoutTakeProduction";
    recipeId: string;
    timestamp: number;
}
