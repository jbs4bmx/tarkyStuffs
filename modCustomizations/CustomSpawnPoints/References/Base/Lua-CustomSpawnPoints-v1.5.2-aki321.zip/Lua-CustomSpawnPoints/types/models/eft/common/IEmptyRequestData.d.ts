export interface IEmptyRequestData {
}
