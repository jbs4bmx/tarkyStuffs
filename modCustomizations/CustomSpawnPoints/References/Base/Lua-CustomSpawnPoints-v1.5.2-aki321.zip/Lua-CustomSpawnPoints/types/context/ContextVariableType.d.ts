export declare enum ContextVariableType {
    SESSION_ID = 0,
    MATCH_INFO = 1
}
