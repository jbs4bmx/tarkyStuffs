import { IUUidGenerator } from "../models/spt/utils/IUuidGenerator";
export declare class UUidGenerator implements IUUidGenerator {
    generate: () => string;
}
